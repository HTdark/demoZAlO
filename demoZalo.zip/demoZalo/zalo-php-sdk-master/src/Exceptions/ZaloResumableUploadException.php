<?php
/**
 * Zalo © 2019
 *
 */

namespace Zalo\Exceptions;

use Zalo\Exceptions\ZaloSDKException;

/**
 * Class ZaloResumableUploadException
 *
 * @package Zalo
 */
class ZaloResumableUploadException extends ZaloSDKException
{
}

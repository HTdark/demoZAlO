<?php
/**
 * Zalo © 2019
 *
 */

namespace Zalo\Exceptions;

use Zalo\Exceptions\ZaloSDKException;

/**
 * Class ZaloAuthorizationException
 *
 * @package Zalo
 */
class ZaloAuthorizationException extends ZaloSDKException
{
}

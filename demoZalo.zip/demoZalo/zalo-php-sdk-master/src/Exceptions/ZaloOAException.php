<?php
/**
 * Zalo © 2019
 *
 */

namespace Zalo\Exceptions;

use Zalo\Exceptions\ZaloSDKException;

/**
 * Description of ZaloOAException
 *
 * @author linhndh
 */
class ZaloOAException extends ZaloSDKException {
    //put your code here
}

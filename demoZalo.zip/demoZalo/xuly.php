<?php
session_start();

require_once './vendor/autoload.php';

use Zalo\Zalo;
use Zalo\ZaloEndPoint;

$config = array(
    'app_id' => '2585893842119614324',
    'app_secret' => 'SUM7EBQU43g6gSRE3o35'
);

$zalo = new Zalo($config);

$helper = $zalo->getRedirectLoginHelper();
$codeVerifier = $_SESSION['code_verifier'];
$zaloToken = $helper->getZaloToken($codeVerifier); // get zalo token
$accessToken = $zaloToken->getAccessToken();

$params = ['fields' => 'id,name,picture'];
$response = $zalo->get(ZaloEndpoint::API_GRAPH_ME, $accessToken, $params);
$result = $response->getDecodedBody(); // result

// Kiểm tra xem đăng nhập Zalo đã thành công hay không
if ($accessToken) {
    // Nếu đã đăng nhập thành công, chuyển hướng đến trang chủ
    header("Location: trangchu.html");
    exit(); // Đảm bảo kết thúc script sau khi chuyển hướng
} else {
    // Nếu không thành công, xử lý theo logic của bạn (ví dụ: hiển thị thông báo lỗi)
    echo "Đăng nhập Zalo không thành công";
}
?>
